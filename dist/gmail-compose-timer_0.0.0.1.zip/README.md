# Gmail compose timer

This is a simple Chrome extension that starts a stopwatch when you start composing an email in Gmail.

The manifest in this repo bypasses the new Content Security Policy (CSP) enforced by Gmail.

### Please use the latest `gmail.js` file from the original repo linked below

**http://github.com/kartiktalwar/gmail.js**

